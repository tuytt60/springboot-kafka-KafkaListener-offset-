package com.springkafka.app4;

import java.util.Map;
import java.util.concurrent.CountDownLatch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.PartitionOffset;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;

import com.springkafka.CommonConfiguration;
import com.springkafka.ConfigProperties;

@SpringBootApplication
@Import({ CommonConfiguration.class, ConfigProperties.class })
@EnableKafka
public class S1pKafkaApplication {

	public static void main(String[] args) throws Exception {
		ConfigurableApplicationContext context = new SpringApplicationBuilder(S1pKafkaApplication.class)
			.web(WebApplicationType.NONE)
			.run(args);
		TestBean testBean = context.getBean(TestBean.class);
		testBean.send("foo");
//		context.getBean(Listener.class).latch.await(60, TimeUnit.SECONDS);
//		context.close();
		context.getBean(Listener.class);
	}

	@Bean
	public TestBean test() {
		return new TestBean();
	}

	@Bean
	public Listener listener() {
		return new Listener();
	}

	public static class TestBean {

		@Autowired
		private ConfigProperties configProperties;

		@Autowired
		private KafkaTemplate<String, String> template;

		public void send(String foo) {
			this.template.send(this.configProperties.getTopic(), foo);
		}

	}

	public static class Listener implements ConsumerSeekAware {

		private final CountDownLatch latch = new CountDownLatch(1);

		@KafkaListener(topicPartitions = @TopicPartition(topic = "${kafka.topic}", partitionOffsets = {
				@PartitionOffset(partition = "0", initialOffset = "0"),
				@PartitionOffset(partition = "1", initialOffset = "0"),
				@PartitionOffset(partition = "2", initialOffset = "0"),
				@PartitionOffset(partition = "3", initialOffset = "0"),
				@PartitionOffset(partition = "4", initialOffset = "0"),
		}))
		@KafkaListener(topicPartitions = @TopicPartition(topic = "${kafka.topic}", partitionOffsets = {
				@PartitionOffset(partition = "0", initialOffset = "0"),
				@PartitionOffset(partition = "1", initialOffset = "0"),
				@PartitionOffset(partition = "2", initialOffset = "0"),
				@PartitionOffset(partition = "3", initialOffset = "0"),
				@PartitionOffset(partition = "4", initialOffset = "0"),
		}))
		public void listen(@Payload String foo, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
			System.out.println("Received: " + foo + " (partition: " + partition + ")");
//			this.latch.countDown();
		}

		@Override
		public void registerSeekCallback(ConsumerSeekCallback callback) {
			// TODO Auto-generated method stub
			callback.seekToBeginning("test", 0);
			
		}

		@Override
		public void onPartitionsAssigned(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
				ConsumerSeekCallback callback) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onIdleContainer(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
				ConsumerSeekCallback callback) {
			// TODO Auto-generated method stub
			
		}

	}

}
