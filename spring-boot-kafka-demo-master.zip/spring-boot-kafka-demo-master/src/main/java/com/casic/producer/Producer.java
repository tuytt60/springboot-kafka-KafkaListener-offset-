package com.casic.producer;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.core.KafkaTemplate;

import com.springkafka.CommonConfiguration;
import com.springkafka.ConfigProperties;

/**
 *
 */
@SpringBootApplication
@Import({ CommonConfiguration.class, ConfigProperties.class })
public class Producer {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		ConfigurableApplicationContext context = new SpringApplicationBuilder(Producer.class)
			.web(WebApplicationType.NONE)
			.run(args);
		TestBean testBean = context.getBean(TestBean.class);
		while(true){
			testBean.send("foo:"+new Date().toLocaleString());
		}
	}

	@Bean
	public TestBean test() {
		return new TestBean();
	}

	public static class TestBean {

		@Autowired
		private ConfigProperties configProperties;

		@Autowired
		private KafkaTemplate<String, String> template;

		public void send(String foo) {
			this.template.send(this.configProperties.getTopic(), foo);
		}

	}

}
